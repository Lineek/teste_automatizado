from behave import given, when, then


@given(u'que eu acesse o site "http://localhost:4200/"')
def step_acessar_site_impl(context):
    raise NotImplementedError(u'STEP: Given que eu acesse o site "http://localhost:4200/"')


@given(u'preencho o campo de usuário "Nome de usuário ou e-mail" com "giannotta.3mpk"')
def step_preencher_campo_usuario_impl(context):
    raise NotImplementedError(u'STEP: Given preencho o campo de usuário "Nome de usuário ou e-mail" com "giannotta.3mpk"')


@given(u'preencho o campo de senha "Senha" com "@3Minhasenhaegrande"')
def step_preencher_campo_senha_impl(context):
    raise NotImplementedError(u'STEP: Given preencho o campo de senha "Senha" com "@3Minhasenhaegrande"')


@given(u'clico no botão "Entrar"')
def step_clicar_botao_entrar_impl(context):
    raise NotImplementedError(u'STEP: Given clico no botão "Entrar"')


@given(u'clico no menu "Processos" depois')
def step_clicar_menu_processos_impl(context):
    raise NotImplementedError(u'STEP: Given clico no menu "Processos" depois')


@given(u'clico no menu "Workflow operacional" depois')
def step_clicar_menu_workflow_operacional_impl(context):
    raise NotImplementedError(u'STEP: Given clico no menu "Workflow operacional" depois')


@given(u'clico no menu "Onboarding" depois')
def step_clicar_menu_onboarding_impl(context):
    raise NotImplementedError(u'STEP: Given clico no menu "Onboarding" depois')


@given(u'que estou na página do onboarding')
def step_esperar_pagina_onboarding_impl(context):
    raise NotImplementedError(u'STEP: Given que estou na página do onboarding')


@when(u'eu clico em "Cadastrar novo cliente"')
def step_clicar_botao_cadastrar_novo_cliente_impl(context):
    raise NotImplementedError(u'STEP: When eu clico em "Cadastrar novo cliente"')


@then(u'o botão "Cadastrar" deve estar desabilitado')
def step_verificar_botao_cadastrar_desabilitado_impl(context):
    raise NotImplementedError(u'STEP: Then o botão "Cadastrar" deve estar desabilitado')


@when(u'preecho o campo CNPJ com o valor "33532348600012"')
def step_preencho_cnpj_invalido_impl(context):
    raise NotImplementedError(u'STEP: When preecho o campo CNPJ com o valor "33532348600012"')


@when(u'preecho o campo CNPJ com o valor "8445384403"')
def step_preencho_cnpj_incompleto_impl(context):
    raise NotImplementedError(u'STEP: When preecho o campo CNPJ com o valor "8445384403"')


@when(u'preecho o campo CNPJ com o valor "59275792000150"')
def step_preencho_cnpj_inexistente_impl(context):
    raise NotImplementedError(u'STEP: When preecho o campo CNPJ com o valor "59275792000150"')


@when(u'preecho o campo CNPJ com o valor "84453844034244"')
def step_preencho_cnpj_existente_impl(context):
    raise NotImplementedError(u'STEP: When preecho o campo CNPJ com o valor "84453844034244"')


@when(u'clico em "Cadastrar"')
def step_clicar_cadastrar_impl(context):
    raise NotImplementedError(u'STEP: When clico em "Cadastrar"')


@then(u'a seção de "Envio de arquivos" deve aparecer')
def step_verificar_secao_envio_arquivos_impl(context):
    raise NotImplementedError(u'STEP: Then a seção de "Envio de arquivos" deve aparecer')

@then(u'a mensagem Cliente já cadastrado esteira de onboarding e encontra-se na etapa cadastro deve ser mostrada')
def step_verificar_mensagem_cadastro_existente_impl(context):
    raise NotImplementedError(u'STEP: Then a mensagem Cliente já cadastrado esteira de onboarding e encontra-se na etapa cadastro deve ser mostrada')